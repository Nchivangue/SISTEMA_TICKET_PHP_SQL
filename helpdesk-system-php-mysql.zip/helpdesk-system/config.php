<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "helpdesk_system";
